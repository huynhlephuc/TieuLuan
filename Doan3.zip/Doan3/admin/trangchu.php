<div class="w3-container" style="margin-top:80px" id="showcase">
    <h1 class="w3-jumbo"><b>Hải Sản Việt - Trang quản lý</b></h1>
    <h1 class="w3-xxxlarge w3-text-red"><b></b></h1>
    <hr style="width:50px;border:5px solid red" class="w3-round">
</div>
<img src="../images/hinh-nen-hai-san.jpg" style="width:100% ; height:700px; margin-bottom: -8px;">